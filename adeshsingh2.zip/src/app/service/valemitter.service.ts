import { Injectable } from '@angular/core';

@Injectable()
export class ValemitterService {

  constructor() { }

}
