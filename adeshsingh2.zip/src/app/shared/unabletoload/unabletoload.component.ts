import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unabletoload',
  templateUrl: './unabletoload.component.html',
  styleUrls: ['./unabletoload.component.css']
})
export class UnabletoloadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
